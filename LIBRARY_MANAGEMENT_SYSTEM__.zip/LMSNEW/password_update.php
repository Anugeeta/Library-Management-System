<?php 
	include "db_connection.php";
	include "navbar.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Change Password</title>
   
	<style type="text/css">
	
 .imgs
{
/*	height: 650px;
	margin-top: 0px;
	
  display: flex;
	flex-wrap: wrap;
  margin:auto;*/
  min-height: 100vh;
    width: 100%;
    background-position: center;
    background-size: cover;
    position: relative;
}
	body{
		background-color:purple;
	}
		.wrapper
		{
			width: 400px;
			height: 400px;
			margin:100px auto;
		
			background-color:black;
			opacity: .8;
			color: white;
			padding: 27px 15px;
		}
		.form-control
		{
			width: 300px;
		}
	</style>
</head>
<body>

<div class="imgs">
	<div class="wrapper">
		<div style="text-align: center;">
			<h1 style="text-align: center; font-size: 35px;font-family: Lucida Console;">Change Your Password</h1>
		</div>
		<div style="padding-left: 30px; ">
		<form action="" method="post" >
			<input type="text" name="name" class="form-control" placeholder="Username" required=""><br>
			<input type="text" name="mail" class="form-control" placeholder="Email" required=""><br>
			<input type="text" name="password" class="form-control" placeholder="New Password" required=""><br>
			<button class="btn btn-default" type="submit" name="submit" >Update</button>
		</form>

	</div>
	
	<?php

		if(isset($_POST['submit']))
		{
			$sql=pg_query($con,"UPDATE member_reg SET password='$_POST[password]' WHERE name='$_POST[name]' AND mail='$_POST[mail]' ;");
			if($sql)
			{
				?>
					<script type="text/javascript">
                alert("The Password Updated Successfully.");
              </script> 

				<?php
			}
			
		}
	?></div>
	</div>
	</div>
</body>
</html>