<?php
	include "db_connection.php";
	include "navbar.php";
?>

<!DOCTYPE html>
<html>
<head>
	<title>Message</title>
</head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<style type="text/css">
	body
	{
			background-image: url("images/msg.png");
			background-repeat: no-repeat;
	}
.wrapper
{
	height: 600px;
	width: 500px;
	background-color: black;
	opacity: .9;
	color: white;
	margin: -20px auto;
	padding: 10px;
}
.form-control
{
	height: 47px;
	width: 76%;
}
.msg
{
	height: 450px;
	overflow-y: scroll;
}
.btn-info
{
	background-color: #02c5b6;
}
.chat
{
	display: flex;
	flex-flow:row wrap;
}
.user .chatbox
{
	height: 50px;
	width: 400px;
	padding: 13px 10px;
	background-color: #821b69;
	color: white;
	border-radius: 10px;
	order: -1;
}
.admin .chatbox
{
	height: 50px;
	width: 400px;
	padding: 13px 10px;
	background-color: #423471;
	color: white;
	border-radius: 10px;
}
</style>

<body>
<?php
	if(isset($_POST['submit']))
	{
		pg_query($con,"INSERT into message VALUES ('', '$_SESSION[login_user]','$_POST[message]','no','member');");

		$res=pg_query($con,"SELECT * from message where name='$_SESSION[login_user]' ;");

	}
	else
	{
		$res=pg_query($con,"SELECT * from message where name='$_SESSION[login_user]' ;");
	}
	pg_query($db,"UPDATE message set status='yes' where sender='admin' and name='$_SESSION[login_user]' ;");
?>

<div class="wrapper">
	<div style="height: 70px; width: 100%; background-color: #2eac8b; text-align: center; color:white; ">
		<h3 style="margin-top: -5px; padding-top: 10px;">Admin</h3>
	</div>
	<div class="msg">
	<?php
	  while ($row=pg_fetch_assoc($res))
		{
			if($row['sender']=='member')
			{
	?>
		<!-------member---------------->
		<br><div class="chat user">
			<div style="float: left; padding-top: 5px;">
				&nbsp
				<?php
                echo "<div style='text-align: left'>
                <img class='img-circle profile-img' height=110 width=120 src='IMG/profile_pic_files/admin-logo-3.png'>
            </div>";
                ?>&nbsp
			</div>
			<div style="float: left;" class="chatbox">
				<?php
					echo $row['message'];
				?>
			</div>
		</div>

<?php
	}
	else
	{
?>
		<!-------admin---------------->

		<br><div class="chat admin">
			<div style="float: left; padding-top: 5px;">
				&nbsp
				<img style="height: 40px; width: 40px; border-radius: 50%;" src="images/p.jpg">
				&nbsp
			</div>
			<div style="float: left;" class="chatbox">
				<?php
					echo $row['message'];
				?>
			</div>
		</div>

		<?php
	}
	}
		?>
	</div>

	<div style="height: 100px; padding-top: 10px;" >
		<form action="" method="post">
			<input type="text" name="message" class="form-control" required="" placeholder="Write Message..." style="float: left"> &nbsp
			<button class="btn btn-info btn-lg" type="submit" name="submit"><span class="glyphicon glyphicon-send "></span>&nbsp Send</button>
		</form>
	</div>
</div>

</body>
</html>