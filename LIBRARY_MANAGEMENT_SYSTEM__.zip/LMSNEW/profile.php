<?php 
	include "db_connection.php";
	include "navbar.php";
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>Profile</title>
 	<style type="text/css">
 		.wrapper
 		{
 			width: 300px;
 			margin: 0 auto;
 			color: white;
 		}
		 body
		 {
			 font-size:20px;

		 }
		 table
		 {
			 margin-left:-50px;
			 
		 }
 	</style>
 </head>
 <body style="background-color: #004528; ">
 
 	<div class="container">
 		<!--<form action="" method="post">
 			<button class="btn btn-default" style="float: right; width: 70px;" name="submit1">Edit</button>
 		</form>
	-->
 		<div class="wrapper">
 			<?php

 				if(isset($_POST['submit1']))
 				{
 					?>
 					<!--	<script type="text/javascript">
 							window.location="edit.php"
 						</script>-->
 					<?php
 				}
 				$q=pg_query($con,"SELECT * FROM member_reg where name='$_SESSION[login_user]' ;");
 			?>
 			<h1 style="text-align: center;">MY PROFILE</h1>

 			<?php
 				$row=pg_fetch_assoc($q);

 				echo "<div style='text-align: center'>
 					<img class='img-circle profile-img' height=110 width=120 src='IMG/profile_pic_files/admin-logo-3.png'>
 				</div>";
 			?>
 		<!--	<div style="text-align: center;"> <h3>Welcome, </h3>
	 			<h4>
	 				<?php echo $_SESSION['login_user']; ?>
	 			</h4>
 			</div>
			-->
 			<?php
			 echo "<br/>";
			 echo "<br/>";
 				echo "<b>";
 				echo "<table class='table table-bordered'>";
	 				echo "<tr>";
	 					echo "<td>";
	 						echo "<b>Name: </b>";
	 					echo "</td>";

	 					echo "<td>";
	 						echo $row['name'];
	 					echo "</td>";
	 				echo "</tr>";

	 				echo "<tr>";
	 					echo "<td>";
	 						echo "<b> Address: </b>";
	 					echo "</td>";
	 					echo "<td>";
	 						echo $row['address'];
	 					echo "</td>";
	 				echo "</tr>";

	 				echo "<tr>";
	 					echo "<td>";
	 						echo "<b> Password: </b>";
	 					echo "</td>";
	 					echo "<td>";
	 						echo $row['password'];
	 					echo "</td>";
	 				echo "</tr>";

	 				echo "<tr>";
	 					echo "<td>";
	 						echo "<b> Email: </b>";	
	 					echo "</td>";
	 					echo "<td>";
	 						echo $row['mail'];
	 					echo "</td>";
	 				echo "</tr>";

	 				echo "<tr>";
	 					echo "<td>";
	 						echo "<b> Contact: </b>";
	 					echo "</td>";
	 					echo "<td>";
	 						echo $row['contact'];
	 					echo "</td>";
	 				echo "</tr>";

	 				
 				echo "</table>";
 				echo "</b>";
 			?>
 		</div>
 	</div>
 </body>
 </html>