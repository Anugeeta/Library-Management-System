
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale = 1">
    <title>CSS Card Flip</title>
    <style>
    body{
    background: #3C5377;
    }

/* THE MAINCONTAINER HOLDS EVERYTHING */
.maincontainer{
  position: absolute;
  width: 400px;
  height: 500px;
  background: none;
  top: 55%;
  left: 35%;
  transform: translate(-50%, -50%);

}
.maincontainer1{
  position: absolute;
  width: 400px;
  height: 500px;
  background: none;
  top: 55%;
  left: 65%;
  transform: translate(-50%, -50%);

}


/* THE CARD HOLDS THE FRONT AND BACK FACES */
.thecard{
  position: relative;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border-radius: 10px;
  transform-style: preserve-3d;
  transition: all 0.8s ease;
}

/* THE PSUEDO CLASS CONTROLS THE FLIP ON MOUSEOVER AND MOUSEOUT */
.thecard:hover{
  transform: rotateY(180deg);
}

/* THE FRONT FACE OF THE CARD, WHICH SHOWS BY DEFAULT */
 .thefront{
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border-radius: 10px;
  backface-visibility: hidden;
  overflow: hidden;
  background: #ffc728;
  color: #000;
}

/* THE BACK FACE OF THE CARD, WHICH SHOWS ON MOUSEOVER */
.theback{
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border-radius: 10px;
  backface-visibility: hidden;
  overflow: hidden;
  background: #fafafa;
  color: #333;
  text-align: center;
  transform: rotateY(180deg);
}


/*This block (starts here) is merely styling for the flip card, and is NOT an essential part of the flip code */
.thefront h1, .theback h1{
  font-family: 'zilla slab', sans-serif;
  padding: 30px;
  font-weight: bold;
  font-size: 24px;
  text-align: center;
}

.thefront p, .theback p{
  font-family: 'zilla slab', sans-serif;
  padding: 20px;
  font-weight: normal;
  font-size: 12px;
  text-align: center;
}
.form-control input{
    font-weight: 200;
    font-size:20px;
    text-align:Center;
    padding:2px;
    border-radius:5px;
}
.heading h1{
    text-align: center;
    color: white;
}
.submit input{
    padding:2px 6px 2px 6px;
    font-size: 25px;
    cursor:pointer;
}
   </style>
  </head>

  <body>
      <div class="heading"><h1>LIBRARY MANAGEMENT SYSTEM</h1></div>
    <div class="maincontainer">

      <div class="thecard">

        <div class="thefront"><h1 style="font-size: 30px;">MEMBER</h1><img src="../MINI_PROJECT/admin.jpg" width="400px"></div>

        <div class="theback"><h1>MEMBER LOGIN</h1>
              
              <hr style="font-size:30px ;">
   
   
   <form action="" method="POST" >
   
   <div class="form-control">
      <br/>
      <input type="number" placeholder="Member name" id="id" name="name" min="0" required/>  
   </div>
   
   <div class="form-control">
      <br/>
      <input type="password" placeholder="Password" id="password" name="password" required/>
   </div>
   
   <br/><br/>
   <div class="submit"> <input type="submit" value="login" name="submit"> </div>
       
   </form>
   </div>
</div>
   </div>
   <?php
if(isset($_POST["submit"]))
{ 
  $host="localhost";
  $user="postgres";
  $pass="12345";
  $db="Library";
  $con=pg_connect("host=$host dbname=$db user=$user password=$pass ") or die("COULD NOT CONNECT TO SERVER\n");
  
  $id=$_POST['name'];
  $password=$_POST['password'];
    $query="SELECT * FROM member_reg WHERE name='$_POST[name]' and password='$_POST[password]'";
    $result=pg_query($con,$query);
    $count=0;
    $count=pg_num_rows($result);
    if($count==0)
    {
        ?>
        <script type="text/javascript">
            alert(" Invalid Membername or Password")
            </script>
        <?php
    }
    else{
      ?>
      <script type="text/javascript">
      window.location="index.php";
      </script>
      <?php
    }

}
?>

    <div class="maincontainer1">

        <div class="thecard">
  
          <div class="thefront"><h1 style="font-size: 30px;">MEMBER</h1><img src="../MINI_PROJECT/mem.jpg" width="400px"></div>
  
          <div class="theback"><h1>MEMBER LOGIN</h1>
              <hr style="font-size:30px ;">
            <form action="" method="POST" >


                <div class="form-control">
                   <br/>
                    <input type="text" placeholder="Member name" id="username" name="name" required/>
                  
                </div>
                
                <div class="form-control">
                   <br/>
                    <input type="password" placeholder="Password" id="password" name="password" required/>
                 
                </div>
                <br/><br/>
         <div class="submit"> <input type="submit" value="login" name="submit"> </div>
          <br/>
         <p style="font-size: 16px;">Don't have an account</p>&nbsp;<a href="index.html">Register here</a>
        </div>
        </div>
        </div>
      </div>

  </body>
</html>
