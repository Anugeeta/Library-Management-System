<?php
  include "db_connection.php";
  include "navbar.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Book Request</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<style type="text/css">

		.srch
		{
			padding-left: 1000px;

		}
		
		body {
			background-image: url("images/1111.jpg");
			background-repeat: no-repeat;
  	font-family: "Lato", sans-serif;
  	transition: background-color .5s;
}

.sidenav {
  height: 100%;
  margin-top: 50px;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #222;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: white;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

#main {
  transition: margin-left .5s;
  padding: 16px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
.img-circle
{
	margin-left: 20px;
}
.h:hover
{
	color:white;
	width: 300px;
	height: 50px;
	background-color: #00544c;
}
.container
{
	height: 600px;
	background-color: black;
	opacity: .8;
	color: white;
}

	</style>

</head>
<body>
<!--_________________sidenav_______________-->
	
	<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>

  			<div style="color: white; margin-left: 60px; font-size: 20px;">

                <?php
                if(isset($_SESSION['login_user']))

                { 	echo "<div style='text-align: left'>
					<img class='img-circle profile-img' height=110 width=120 src='IMG/profile_pic_files/admin-logo-3.png'>
				</div>";
					echo "</br></br>";

                    echo "Welcome ".$_SESSION['login_user']; 
                }
                ?>
            </div><br><br>

 
  <div class="h"> <a href="books.php">Books</a></div>
  <div class="h"> <a href="request.php">Book Request</a></div>
  <?php  if(isset($_SESSION['login_user']))

{ echo "<div class='h'> <a href='profile.php'>My Profile</a></div>";
}
?>
</div>

<div id="main">
  
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; open</span>


	<script>
	function openNav() {
	  document.getElementById("mySidenav").style.width = "300px";
	  document.getElementById("main").style.marginLeft = "300px";
	  document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
	}

	function closeNav() {
	  document.getElementById("mySidenav").style.width = "0";
	  document.getElementById("main").style.marginLeft= "0";
	  document.body.style.backgroundColor = "white";
	}
	</script>
	<br>

<div class="container">
	<h3 style="text-align: center;">Request of Book</h3>

	<?php
	
    if(isset($_SESSION['login_user']))
    {
        $q=pg_query($con,"SELECT * from issue_book where name='$_SESSION[login_user]';");

        if(pg_num_rows($q)==0)
        {
            echo "There's no pending request.";
        }
        else
        {
    echo "<table class='table table-bordered' >";
			echo "<tr style='background-color: #6db6b9e6;'>";
      
            //Table header
            echo "<th>"; echo "Book ID";	echo "</th>";
            echo "<th>"; echo "Approve Status";  echo "</th>";
            echo "<th>"; echo "Issue date";  echo "</th>";
            echo "<th>"; echo "Return date";  echo "</th>";
  
        echo "</tr>";	

        while($row=pg_fetch_assoc($q))
        {
            echo "<tr>";
            echo "<td>"; echo $row['book_id']; echo "</td>";
            echo "<td>"; echo $row['approve']; echo "</td>";
            echo "<td>"; echo $row['issue']; echo "</td>";
            echo "<td>"; echo $row['return']; echo "</td>";
         
            
            echo "</tr>";
        }
    echo "</table>";
        }
    }
        /*if button is not pressed.*/
    else
    {
        echo "</br></br></br>"; 
        echo "<h2><b>";
        echo "Please login first to see the request info..";
        echo "</b></h2>";
    }

	/*if(isset($_SESSION['login_user']))
	{
		$sql= "SELECT member_reg.name,BOOKS.book_id,name,author,price,availability FROM member_reg inner join issue_book ON member_reg.name=issue_book.name inner join BOOKS ON issue_book.book_id=BOOKS.book_id WHERE issue_book.approve =''";
		$res= pg_query($db,$sql);

		if(pg_num_rows($res)==0)
			{
				echo "<h2><b>";
				echo "There's no pending request.";
				echo "</h2></b>";
			}
		else
		{
			echo "<table class='table table-bordered' >";
			echo "<tr style='background-color: #6db6b9e6;'>";
				//Table header
				
				echo "<th>"; echo "Member name";  echo "</th>";
				echo "<th>"; echo "Book ID";  echo "</th>";
				echo "<th>"; echo "Book Name";  echo "</th>";
				echo "<th>"; echo "Authors Name";  echo "</th>";
				echo "<th>"; echo "price";  echo "</th>";
				echo "<th>"; echo "Availability";  echo "</th>";
				
			echo "</tr>";	

			while($row=pg_fetch_assoc($res))
			{
				echo "<tr>";
				echo "<td>"; echo $row['name']; echo "</td>";
				echo "<td>"; echo $row['book_id']; echo "</td>";
				echo "<td>"; echo $row['title']; echo "</td>";
				echo "<td>"; echo $row['author']; echo "</td>";
				echo "<td>"; echo $row['price']; echo "</td>";
				echo "<td>"; echo $row['availability']; echo "</td>";
				echo "</tr>";
			}
		echo "</table>";
		}
	}
	/*
	if(isset($_SESSION['login_user']))
		{
			$q=mysqli_query($db,"SELECT * from issue_book where username='$_SESSION[login_user]' ;");

			if(mysqli_num_rows($q)==0)
			{
				echo "<h2><b>";
				echo "There's no pending request";
				echo "</h2></b>";
			}
			else
			{
		echo "<table class='table table-bordered table-hover' >";
			echo "<tr style='background-color: #6db6b9e6;'>";
				//Table header
				
				echo "<th>"; echo "Book-ID";  echo "</th>";
				echo "<th>"; echo "Approve Status";  echo "</th>";
				echo "<th>"; echo "Issue Date";  echo "</th>";
				echo "<th>"; echo "Return Date";  echo "</th>";
				
			echo "</tr>";	

			while($row=mysqli_fetch_assoc($q))
			{
				echo "<tr>";
				echo "<td>"; echo $row['bid']; echo "</td>";
				echo "<td>"; echo $row['approve']; echo "</td>";
				echo "<td>"; echo $row['issue']; echo "</td>";
				echo "<td>"; echo $row['return']; echo "</td>";
				
				echo "</tr>";
			}
		echo "</table>";
			}
		}
		else
		{
			echo "</br></br></br>"; 
			echo "<h2><b>";
			echo " Please login first to see the request information.";
			echo "</b></h2>";
		}
		*/
		?>
	</div>
</div>
</body>
</html>