<?php
  session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>
	</title>

	  <link rel="stylesheet" type="text/css" href="styles.css">
	  <meta charset="utf-8">
  
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
<style>
  .intro{
    color:white;
    font-size:20px;
    text-align:center;
  }
  </style>
</head>
<body>

	    <nav>
       <span class="intro">ONLINE LIBRARY MANAGEMENT SYSTEM</span>
       
          <ul>
            <li><a href="index.php">HOME</a></li>
            <li><a href="books.php">BOOKS</a></li>
            <li><a href="feedback.php">FEEDBACK</a></li>
          </ul>
          <?php
            if(isset($_SESSION['login_user']))
            {?>

                <ul>
                  <li><a href="">
                    <div style="color: white">
                      <?php
                        echo "Welcome ".$_SESSION['login_user']; 
                      ?>
                    </div>
                  </a></li>
                  <li><a href="logout.php"><span> LOGOUT</span></a></li>
                </ul>
              <?php
            }
            else
            {   ?>
              <ul>

                <li><a href="student_login.php"><span> LOGIN</span></a></li>
                
                <li><a href="registration.php"><span> SIGNUP</span></a></li>
              </ul>
                <?php
            }
          ?>

          

      </div>
    </nav>

</body>
</html>