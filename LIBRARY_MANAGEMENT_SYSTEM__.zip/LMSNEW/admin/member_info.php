<?php
include "navbar.php";
?>

<!-- DISPLAYING DETAILS OF ALL MEMBERS -->
<!DOCTYPE html>
<html>
    <head>
        <style>
          *{
              margin:0;

          }
            .content-table {
  border-collapse: collapse;
  margin: 30px 0;
  font-size: 0.9em;
  min-width: 900px;
  border-radius: 5px 5px 0 0;
  overflow: hidden;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
  margin-left:200px;
  width:1000px;

}

.content-table thead tr {
  background-color: #98006a;
  color: #ffffff;
  text-align: left;
  font-weight: bold;
}

.content-table th,
.content-table td {
  padding: 12px 15px;
}
.content-table th{
    background-color: #98006a;
    color:white;
    font-size:15px;
}

.content-table tbody tr {
  border-bottom: 1px solid #98006a;
}

.content-table tbody tr:nth-of-type(even) {
  background-color: #f3f3f3;
}

.content-table tbody tr:last-of-type {
  border-bottom: 2px solid #980084;
}

.content-table tbody tr.active-row {
  font-weight: bold;
  color: #98007f;
}
h2{
  text-align:center;
  margin-top:50px;
  font-size:35px;
 
}
            </style>
        <body>
          <h2> DETAILS OF ALL MEMBERS </h2>
            <table class="content-table">
                <tr>
                    <th>Name</th>
                    <th>Mail-id</th>
                    <th>Password</th>
                    <th>Contact</th>
                    <th>Address</th>     
                </tr>
<?php
                $host="localhost";
                $user="postgres";
                $pass="12345";
                $db="Library";
                $con=pg_connect("host=$host dbname=$db user=$user password=$pass ") or die("COULD NOT CONNECT TO SERVER\n");
                if(!$con)
{
    echo "ERROR: UNABLE TO OPEN DB\n";
}
else{
    $sql="SELECT * FROM member_reg ";
    $result=pg_query($con,$sql);
   if(pg_num_fields($result)>0){
    
        while($row=pg_fetch_row($result))
        { 
          
        echo  "<tr><td> $row[0] </td><td> $row[1] </td><td> $row[2]  </td><td> $row[3]  </td><td> $row[4] </td></tr>";
     //  echo "<tr><td>".$row["book_id"] ."</td><td>". $row["title"] ."</td><td>". $row["author"] ."</td><td>". $row["price"] ."</td><td>". $row["availability"] ."</td></tr>";
  
    }
        echo "</table>";
   }
else{
        echo "0 result";
    } 
    pg_close($con);  
            }
                  
?>  
        </body>
    </head>
</html>
	