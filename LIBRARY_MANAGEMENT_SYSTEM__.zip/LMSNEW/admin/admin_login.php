
<?php
include "db_connection.php";
include "navbar.php";
?>
<!DOCTYPE html>
<html>
<head>

  <title>Admin Login</title>
  <link rel="stylesheet" type="text/css" href="styles.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
  
  <style type="text/css">
      body {
	background-color: #9b59b6;
	font-family: 'Open Sans', sans-serif;
margin:0;
}

.container {
	background-color: #fff;
  margin-top:40px;
	border-radius: 5px;
	box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
	overflow: hidden;
	width: 400px;
	max-width: 100%;
  
}

.header1 {
	border-bottom: 1px solid #f0f0f0;
	background-color: #f7f7f7;
	padding: 20px 40px;
}

.header1 h2 {
	margin: 0;
}

.form {
	padding: 30px 40px;	
}

.form-control1 {
	margin-bottom: 10px;
	padding-bottom: 20px;
	position: relative;
}

.form-control1 label {
	display: inline-block;
	margin-bottom: 5px;
}

.form-control1 input {
	border: 2px solid #f0f0f0;
	border-radius: 4px;
 display:block;
	font-family: inherit;
	font-size: 14px;
	padding: 10px;
	width: 100%;
}



.form-control1 input {
	border-color: /*#2ecc71;*/ lightgrey;
}

.form-control1.error input {
	border-color: #e74c3c;
}

.form-control1 i {
	visibility: hidden;
	position: absolute;
	top: 40px;
	right: 10px;
}

.form-control1.success i.fa-check-circle {
	color: #2ecc71;
	visibility: visible;
}

.form-control1.error i.fa-exclamation-circle {
	color: #e74c3c;
	visibility: visible;
}

.form-control1 small {
	color: #e74c3c;
	position: absolute;
	bottom: 0;
	left: 0;
	visibility: hidden;
}

.form-control1.error small {
	visibility: visible;
}

.btn {
	background-color: #8e44ad;
	border: 2px solid #8e44ad;
	border-radius: 4px;
	color: #fff;
	display: block;
	font-family: inherit;
	font-size: 16px;
	padding: 10px;
	margin-top: 20px;
	width: 100%;
}


  </style>   
</head>
<body>
<?php
if(isset($_POST["submit"]))
{ 

  $id=$_POST['id'];
  $password=$_POST['password'];
    $query="SELECT * FROM admin_reg WHERE id='$_POST[id]' and password='$_POST[password]'";
    $result=pg_query($con,$query);
    $count=0;
    $count=pg_num_rows($result);
    if($count==0)
    {
        ?>
        <script type="text/javascript">
            alert(" Invalid Membername or Password");
            </script>
        <?php
    }
    else{
      $_SESSION['login_user']=$_POST['password'];
     
      ?>
      <script type="text/javascript">
      window.location="index.php";
      </script>
      <?php
    }

}
?>

  
  <div class="container">
    <div class="header1">
    <h1 style="text-align: center; font-size: 35px;font-family: Lucida Console;">Library Management System</h1>
        <h1 style="text-align: center; font-size: 25px;">Admin Login Form</h1><br>
  
      <form  action="" method="POST">
        <div class="form-control1">
          <input type="number" name="id" placeholder="Admin id" required=""> </div><br>
          <div class="form-control1"> <input type="password" name="password" placeholder="Password" required=""> </div><br>
         <input class="btn" type="submit" name="submit" value="Login"> 
         </div>
    
    </form>
    </div>
  </div>

</body>
</html>