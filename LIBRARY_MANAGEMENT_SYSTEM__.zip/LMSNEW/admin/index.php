<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>
		Online Library Management System
	</title>
	<meta charset="utf-8">
	   
	<meta name="author" content="Anugeeta(2020115011)"> 
	<link rel="stylesheet" type="text/css" href="styles.css">
	
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
   <!--
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->


<style>
/*
*{
  margin: 0;
  padding: 0;
  list-style: none;
  text-decoration: none;
}
  body{
    font-family: sans-serif;
 
    user-select: none;
    overflow: hidden;
  }

  nav{
    height: 70px;
    background: #063247;
    box-shadow: 0 3px 15px rgba(0,0,0,.4);
  }
  nav ul{
    float: right;
    margin-right: 30px;
  }
  nav ul li{
    display: inline-block;
  }
  nav ul li a{
    color: white;
    display: block;
    padding: 0 15px;
    line-height: 70px;
    font-size: 20px;
    background: #063247;
    transition: .5s;
  }
  nav ul li a:hover,
  nav ul li a.active1{
    color: #23dbdb;
  }
  nav ul ul{
    position: absolute;
    top: 85px;
    border-top: 3px solid #23dbdb;
    opacity: 0;
    visibility: hidden;
  }
  nav ul li:hover > ul{
    top: 70px;
    opacity: 1;
    visibility: visible;
    transition: .3s linear;
  }
  nav ul ul li{
    width: 150px;
    display: list-item;
    position: relative;
    border: 1px solid #042331;
    border-top: none;
  }
  nav ul ul li a{
    line-height: 50px;
  }
  nav ul ul ul{
    border-top: none;
  }
  nav ul ul ul li{
    position: relative;
    top: -70px;
    left: 150px;
  }
  nav ul ul li a i{
    margin-left: 45px;
  }
 
  nav img{
    margin-top:10px;
    margin-left:40px;
  }
   */
/*
	nav
	{
		float: right;
		word-spacing: 30px;
		padding: 20px;
	}
	nav li 
	{
		display: inline-block;
		line-height: 80px;
	}
	*/
  section .sec_img{
  min-height: 100vh;
    width: 100%;
    background-position: center;
    background-size: cover;
    position: relative;
    background-image: url("../IMG/l8.jpg");
}
.box
{
	height: 300px;
	width: 450px;
	background-color: #030002;
	margin: 70px auto;
	opacity: .6;
	color: white;
}
</style>
</head>


<body>
	<!--<div class="wrapper">
		<header>
		<div class="logo">
			<img src="IMG/9.png">
			<h1 style="color: black;">ONLINE LIBRARY MANAGEMENT SYSTEM</h1>
		-->
		<?php
		      if(isset($_SESSION['login_user']))
			  {
				  ?>
				<nav>
				<ul>
					<li><a href="index.php">HOME</a></li>
					<li><a href="books.php">BOOKS</a></li>
          <li><a href="members_info.php">MEMBERS-INFO</a></li>
					<li><a href="logout.php">LOGOUT</a></li>
					<li><a href="feedback.php">FEEDBACK</a></li>
				</ul>
			</nav>
			<?php
			  }
			  else{
				  ?>
				<nav>
				<ul>
					<li><a href="index.php">HOME</a></li>
					<li><a href="books.php">BOOKS</a></li>
					<li><a href="admin_login.php">ADMINLOGIN</a></li>
					
					<li><a href="feedback.php">FEEDBACK</a></li>
				</ul>
			</nav>
			<?php
			  }
			  ?>
		</header>
		<section>
		<div class="sec_img">
			<br><br><br>
			<div class="box">
				<br><br><br><br>
				<h1 style="text-align: center; font-size: 35px;">Welcome to library</h1><br><br>
				<h1 style="text-align: center;font-size: 25px;">Opens at: 09:00 </h1><br>
				<h1 style="text-align: center;font-size: 25px;">Closes at: 15:00 </h1><br>
			</div>
		</div>
		</section>
		<footer>
			<p style="color:white;  text-align: center; ">
				<br><br>
				Email: Online.library@gmail.com <br>
				Mobile: +9150449488
			</p>
		</footer>
	</div>
</body>

</html>