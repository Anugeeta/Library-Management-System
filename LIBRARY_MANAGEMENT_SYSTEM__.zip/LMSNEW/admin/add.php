<?php
  include "navbar.php";
  include "db_connection.php";
?>

<!DOCTYPE html>
<html>
<head>
	<title>Books</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<style type="text/css">
    *{
  margin: 0;
  padding: 0;
  list-style: none;
  text-decoration: none;
}
  body{
    font-family: sans-serif;
   /* 
    user-select: none;
    overflow: hidden;*/
  }

  /*
  nav{
    height: 70px;
    background: #063247;
    box-shadow: 0 3px 15px rgba(0,0,0,.4);
  }
  nav ul{
    float: right;
    margin-right: 30px;
  }
  nav ul li{
    display: inline-block;
  }
  nav ul li a{
    color: white;
    display: block;
    padding: 0 15px;
    line-height: 70px;
    font-size: 20px;
    background: #063247;
    transition: .5s;
  }
  nav ul li a:hover,
  nav ul li a.active1{
    color: #23dbdb;
  }
  nav ul ul{
    position: absolute;
    top: 85px;
    border-top: 3px solid #23dbdb;
    opacity: 0;
    visibility: hidden;
  }
  nav ul li:hover > ul{
    top: 70px;
    opacity: 1;
    visibility: visible;
    transition: .3s linear;
  }
  nav ul ul li{
    width: 150px;
    display: list-item;
    position: relative;
    border: 1px solid #042331;
    border-top: none;
  }
  nav ul ul li a{
    line-height: 50px;
  }
  nav ul ul ul{
    border-top: none;
  }
  nav ul ul ul li{
    position: relative;
    top: -70px;
    left: 150px;
  }
  nav ul ul li a i{
    margin-left: 45px;
  }
 
  nav img{
    margin-top:10px;
    margin-left:40px;
  }
 */

  body{
     background-color: lightgrey;
  }
 

 
.head_img{
  margin-left:600px;
}
  
		.srch
		{
			padding-left: 1000px;

		}
		
		body {
  background-color: /*#024629*/#98006a;
  font-family: "Lato", sans-serif;
  transition: background-color .5s;
}


.sidenav {

  height: 100%;
  margin-top: 50px;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #222;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: white;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

#main {
  transition: margin-left .5s;
  padding: 16px 16px;
  box-sizing:border-box;
  border-radius:5px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
.img-circle
{
	margin-left: 20px;
}
.h:hover
{
	color:white;
	width: 300px;
	height: 50px;
	background-color: #00544c;
}

.book
{
    width: 400px;
    margin: 0px auto;
}
.form-control1
{
  background-color: #080707;
  color: white;
  height: 40px;
  width:70%;
}

.container {
	background-color: #fff;
	border-radius: 5px;
	box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
	overflow: hidden;
	width: 400px;
	max-width: 100%;
  margin-left:500px;
}

.header1 {
	border-bottom: 1px solid #f0f0f0;
	background-color: #f7f7f7;
	padding: 20px 40px;
}

.header1 h2 {
	margin: 0;
}

.form {
	padding: 30px 40px;	
}

.form-control1 {
	margin-bottom: 10px;
	padding-bottom: 20px;
	position: relative;
}

.form-control1 label {
	display: inline-block;
	margin-bottom: 5px;
}

.form-control1 input {
	border: 2px solid #f0f0f0;
	border-radius: 4px;
	display: block;
	font-family: inherit;
	font-size: 14px;
	padding: 10px;
	width: 100%;
  background-color:black;
  color:white;
}

.form-control1 input:focus {
	outline: 0;
	border-color: #777;
}

.form-control1.success input {
	border-color: #2ecc71;
}

.form-control1.error input {
	border-color: #e74c3c;
}

.form-control1 i {
	visibility: hidden;
	position: absolute;
	top: 40px;
	right: 10px;
}

.form-control1.success i.fa-check-circle {
	color: #2ecc71;
	visibility: visible;
}

.form-control1.error i.fa-exclamation-circle {
	color: #e74c3c;
	visibility: visible;
}

.form-control1 small {
	color: #e74c3c;
	position: absolute;
	bottom: 0;
	left: 0;
	visibility: hidden;
}

.form-control1.error small {
	visibility: visible;
}
.btn {
	background-color: #98006a/*#8e44ad*/;
	border: 2px solid #8e44ad;
	border-radius: 4px;
	color: #fff;
	display: block;
	font-family: inherit;
	font-size: 16px;
	padding: 10px;
	margin-top: 20px;
	width: 70%;
}
.btn:hover{
  background-color:#98006b;
}




	</style>


</head>
<body>
  <!--
<nav> <span style="color:white;font-size:20px;">Online Library Management System</span>
			
 			<ul>
         		<li><a href="index.php">HOME</a></li>
					<li><a href="books.php">BOOKS</a></li>
					<li><a href="admin_login.php">LOGIN</a></li>
					<li><a href="feedback.php">FEEDBACK</a></li>
					<li><a href="member_info.php">MEMBERS INFO</a></li>
				</ul>
			</nav>
      !-->
	<!--_________________sidenav_______________-->
	
	<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>

  			<div style="color: white; margin-left: 60px; font-size: 20px;">

                <?php
                if(isset($_SESSION['login_user']))

                { 	echo "<div style='text-align: left'>
                  <img class='img-circle profile-img' height=110 width=120 src='../IMG/profile_pic_files/admin-logo-3.png'>
                </div>";
                echo "</br></br>";

                    echo "Welcome ".$_SESSION['login_user']; 
                }
                ?>
            </div><br><br>

 <div class="h"> <a href="add.php">Add Books</a> </div> 
  <div class="h"> <a href="books.php">Delete Books</a></div>
  <div class="h"> <a href="request1.php">Book Request</a></div>
  <div class="h"> <a href="issue_info.php">Issue Information</a></div>
  
  <div class="h"><a href="expired.php">Expired List</a></div>
</div>

<div id="main">
			
  <span  style="color:white;font-size:20px;" onclick="openNav()">&#9776; open</span>
 <br/> <div class="container">    
 <div class="header1">       
   
    <h2 style="color:black; font-family: Lucida Console; text-align: center"><b>Add New Books</b></h2><br/><br/>
 
    <form class="book" action="" method="post">

    <input type="number" name="book_id" class="form-control1" min="0" placeholder="Book id" required=""><br><br>
        <input type="text" name="title" class="form-control1" placeholder="Book Name" required=""><br><br>
        <input type="text" name="author" class="form-control1" placeholder="Authors Name" required=""><br><br>
        <input type="number" name="price" class="form-control1" placeholder="Price" min="0" required=""><br><br>
        <input type="number" name="availability" class="form-control1" placeholder="Availability" min="0" required=""><br>
       
        <input class="btn" type="submit" name="submit" value="ADD">
        </div>
  </div>
    </form>
 
             
<?php
    if(isset($_POST['submit']))
    {
    if(isset($_SESSION['login_user']))
    {
        pg_query($con,"INSERT INTO BOOKS VALUES ('$_POST[book_id]', '$_POST[title]', '$_POST[author]', '$_POST[price]', '$_POST[availability]') ;");
        ?>
          <script type="text/javascript">
            alert("Book Added Successfully.");
          </script>

        <?php
    }
    else{
      ?>
        <script type="text/javascript">
            alert("You need to login first...");
          </script>
          <?php
    }
      }
      
?>
</div>
<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "300px";
  document.getElementById("main").style.marginLeft = "300px";
  document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
  document.body.style.backgroundColor = "#024629";
}
</script>

</body>
