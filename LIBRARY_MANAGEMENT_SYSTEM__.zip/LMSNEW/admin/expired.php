<?php
  include "db_connection.php";
  include "navbar.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Book Request</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<style type="text/css">

		.srch
		{
			padding-left: 70%;

		}
		.form-control
		{
			width: 300px;
			height: 40px;
			background-color: black;
			color: white;
		}
		
		body {
			background-image: url("images/aa.jpg");
			background-repeat: no-repeat;
  	font-family: "Lato", sans-serif;
  	transition: background-color .5s;
}

.sidenav {
  height: 100%;
  margin-top: 50px;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #222;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: white;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

#main {
  transition: margin-left .5s;
  padding-left: 15px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
.img-circle
{
	margin-left: 20px;
}
.h:hover
{
	color:white;
	width: 300px;
	height: 50px;
	background-color: #00544c;
}
.container
{
	height: 800px;
  width: 85%;
	background-color: black;
	opacity: .8;
	color: white;
  margin-top: -65px;
}
.scroll
{
  width: 100%;
  height: 400px;
  overflow: auto;
}
th,td
{
  width: 10%;
}

	</style>

</head>
<body>
<!--_________________sidenav_______________-->
	
	<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>

  			<div style="color: white; margin-left: 60px; font-size: 20px;">

                <?php
                if(isset($_SESSION['login_user']))

                { echo "<div style='text-align: left'>
                  <img class='img-circle profile-img' height=110 width=120 src='../IMG/profile_pic_files/admin-logo-3.png'>
                </div>"; echo "</br></br>";

                    echo "Welcome ".$_SESSION['login_user']; 
                }
                ?>
            </div><br><br>

 
            <div class="h"> <a href="add.php">Add Books</a> </div> 
  <div class="h"> <a href="books.php">Delete Books</a></div>
  <div class="h"> <a href="request1.php">Book Requests</a> </div> 
  <div class="h"> <a href="issue_info.php">Issue Information</a></div>
  
  <div class="h"><a href="expired.php">Expired List</a></div>
</div>

<div id="main">
  
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; open</span>


	<script>
	function openNav() {
	  document.getElementById("mySidenav").style.width = "300px";
	  document.getElementById("main").style.marginLeft = "300px";
	  document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
	}

	function closeNav() {
	  document.getElementById("mySidenav").style.width = "0";
	  document.getElementById("main").style.marginLeft= "0";
	  document.body.style.backgroundColor = "white";
	}
	</script>
 
  <br/><br/>  <br/><br/>  <br/><br/>  
  <div class="container">
  <br/><br/>
    <?php
      if(isset($_SESSION['login_user']))
      {
        ?>

      <div style="float: left; padding: 25px;">
     
      <form method="post" action="">
          <button name="submit2" type="submit" class="btn btn-default" style="background-color: #06861a; color: yellow;">RETURNED</button> 
                      &nbsp&nbsp
          <button name="submit3" type="submit" class="btn btn-default" style="background-color: red; color: yellow;">EXPIRED</button>
      </form>
      </div>

          <div class="srch" >
          <br>
          <form method="post" action="" name="form1">
            <input type="text" name="name" class="form-control" placeholder="Member name" required=""><br>
            <input type="number" name="book_id" class="form-control" placeholder="Book ID" required=""><br>
            <button class="btn btn-default" name="submit" type="submit">Submit</button><br><br>
          </form>
        </div>
        <?php

        if(isset($_POST['submit']))
        {
          $var1='<p style="color:yellow; background-color:green;">RETURNED</p>';
          pg_query($con,"UPDATE issue_book SET approve='$var1' where name='$_POST[name]' and book_id='$_POST[book_id]' ");

          pg_query($con,"UPDATE BOOKS SET availability = availability+1 where book_id='$_POST[book_id]' ");
        }
      }
    
    $c=0;

      
         $ret='<p style="color:yellow; background-color:green;">RETURNED</p>';
         $exp='<p style="color:yellow; background-color:red;">EXPIRED</p>';
        
        if(isset($_POST['submit2']))
        {
          
        $sql="SELECT member_reg.name,books.book_id,title,author,price,approve,issue,issue_book.return FROM member_reg inner join issue_book ON member_reg.name=issue_book.name inner join books ON issue_book.book_id=books.book_id WHERE issue_book.approve ='$ret' ORDER BY issue_book.return DESC";
        $res=pg_query($con,$sql);

        }
       else if(isset($_POST['submit3']))
        {
        $sql="SELECT member_reg.name,BOOKS.book_id,title,author,price,approve,issue,issue_book.return FROM member_reg inner join issue_book ON member_reg.name=issue_book.name inner join BOOKS ON issue_book.book_id=books.book_id WHERE issue_book.approve ='$exp' ORDER BY issue_book.return DESC";
        $res=pg_query($con,$sql);
        }
        else
        {
        $sql="SELECT member_reg.name,BOOKS.book_id,title,author,price,approve,issue,issue_book.return FROM member_reg inner join issue_book ON member_reg.name=issue_book.name inner join BOOKS ON issue_book.book_id=books.book_id WHERE issue_book.approve !='' and issue_book.approve !='Yes' ORDER BY issue_book.return DESC";
        $res=pg_query($con,$sql);
        }

        echo "<table class='table table-bordered' style='width:100%;' >";
        //Table header
        
        echo "<tr style='background-color: #6db6b9e6;'>";
        echo "<th>"; echo "Membername";  echo "</th>";
      
        echo "<th>"; echo "Book ID";  echo "</th>";
        echo "<th>"; echo "Book Name";  echo "</th>";
        echo "<th>"; echo "Authors Name";  echo "</th>";
        echo "<th>"; echo "Price";  echo "</th>";
        echo "<th>"; echo "Status";  echo "</th>";
        echo "<th>"; echo "Issue Date";  echo "</th>";
        echo "<th>"; echo "Return Date";  echo "</th>";

      echo "</tr>"; 
      echo "</table>";

       echo "<div class='scroll'>";
        echo "<table class='table table-bordered' >";
      while($row=pg_fetch_assoc($res))
      {
        echo "<tr>";
          echo "<td>"; echo $row['name']; echo "</td>";
      
          echo "<td>"; echo $row['book_id']; echo "</td>";
          echo "<td>"; echo $row['title']; echo "</td>";
          echo "<td>"; echo $row['author']; echo "</td>";
          echo "<td>"; echo $row['price']; echo "</td>";
          echo "<td>"; echo $row['approve']; echo "</td>";
          echo "<td>"; echo $row['issue']; echo "</td>";
          echo "<td>"; echo $row['return']; echo "</td>";
        echo "</tr>";
      }
    echo "</table>";
        echo "</div>";

    ?>
  </div>
</div>
</body>
</html>