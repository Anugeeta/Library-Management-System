
<?php
                $host="localhost";
                $user="postgres";
                $pass="12345";
                $db="Library";
                $con=pg_connect("host=$host dbname=$db user=$user password=$pass ") or die("COULD NOT CONNECT TO SERVER\n");
                if(!$con)
{
    echo "ERROR: UNABLE TO OPEN DB\n";
}
?>