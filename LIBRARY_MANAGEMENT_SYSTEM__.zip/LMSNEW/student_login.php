<?php
include "navbar.php";
?>
<!DOCTYPE html>
<html>
<head>

  <title>Student Login</title>
  <link rel="stylesheet" type="text/css" href="styles.css">
  <meta charset="utf-8">
  
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
  
  <style type="text/css">
    
    body {
	background-color: #9b59b6;
	font-family: 'Open Sans', sans-serif;
margin:0;
}

.container {
	background-color: #fff;
  margin-top:40px;
	border-radius: 5px;
	box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
	overflow: hidden;
	width: 400px;
	max-width: 100%;
  
}

.header1 {
	border-bottom: 1px solid #f0f0f0;
	background-color: #f7f7f7;
	padding: 20px 40px;
}

.header1 h2 {
	margin: 0;
}

.form {
	padding: 30px 40px;	
}

.form-control1 {
	margin-bottom: 10px;
	padding-bottom: 20px;
	position: relative;
}

.form-control1 label {
	display: inline-block;
	margin-bottom: 5px;
}

.form-control1 input {
	border: 2px solid #f0f0f0;
	border-radius: 4px;
 display:block;
	font-family: inherit;
	font-size: 14px;
	padding: 10px;
	width: 100%;
}



.form-control1.success input {
	border-color: #2ecc71;
}

.form-control1.error input {
	border-color: #e74c3c;
}

.form-control1 i {
	visibility: hidden;
	position: absolute;
	top: 40px;
	right: 10px;
}

.form-control1.success i.fa-check-circle {
	color: #2ecc71;
	visibility: visible;
}

.form-control1.error i.fa-exclamation-circle {
	color: #e74c3c;
	visibility: visible;
}

.form-control1 small {
	color: #e74c3c;
	position: absolute;
	bottom: 0;
	left: 0;
	visibility: hidden;
}

.form-control1.error small {
	visibility: visible;
}

.btn {
	background-color: #8e44ad;
	border: 2px solid #8e44ad;
	border-radius: 4px;
	color: #fff;
	display: block;
	font-family: inherit;
	font-size: 16px;
	padding: 10px;
	margin-top: 20px;
	width: 100%;
}


  </style>   
</head>
<body>
<?php
if(isset($_POST["submit"]))
{ 
  $host="localhost";
  $user="postgres";
  $pass="12345";
  $db="Library";
  $con=pg_connect("host=$host dbname=$db user=$user password=$pass ") or die("COULD NOT CONNECT TO SERVER\n");
  
  $id=$_POST['name'];
  $password=$_POST['password'];
    $query="SELECT * FROM member_reg WHERE name='$_POST[name]' and password='$_POST[password]'";
    $result=pg_query($con,$query);
    $count=0;
    $count=pg_num_rows($result);
    if($count==0)
    {
        ?>
        <script type="text/javascript">
            alert(" Invalid Membername or Password");
            </script>
        <?php
    }
    else{
      $_SESSION['login_user']=$_POST['name'];
      ?>
      <script type="text/javascript">
      window.location="index.php";
      </script>
      <?php
    }

}
?>
<!--
    <nav class="navbar navbar-inverse">
      <div class="container-fluid">
          <div class="navbar-header">
            <a class="navbar-brand active">ONLINE LIBRARY MANAGEMENT SYSTEM</a>
          </div>
          <ul class="nav navbar-nav">
            <li><a href="index.php">HOME</a></li>
            <li><a href="books.php">BOOKS</a></li>
            <li><a href="feedback.php">FEEDBACK</a></li>
          </ul>

      </div>
    </nav>
-->
    <div class="container">

  <div class="header1">
   <br>
  

        <h1 style="text-align: center; font-size: 35px;font-family: Lucida Console;">Library Management System</h1>
        <h1 style="text-align: center; font-size: 25px;">Member Login Form</h1><br>
      <form  action="" method="POST">
        
        <div class="form-control1">
          <input type="text" name="name" placeholder="Username" required=""> </div>
          <div class="form-control1"> 
          <input type="password" name="password" placeholder="Password" required=""> <br>
          <input class="btn" type="submit" name="submit" value="Login"> 
        </div>
      <p style="color: black; padding-left: 12px;text-align:center;">
       
        <a style="color:purple;font-size:20px;text-decoration:underline;" href="password_update.php">Forgot password?</a>   <!-- New to this website?<a style="color:black;" href="registration.php">Sign Up</a>
--> </p>
</div>
    </form>
    </div>
  </div>


</body>
</html>